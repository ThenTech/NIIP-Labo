// BinTree3.h

#ifndef __BINTREE3_H
#define __BINTREE3_H

#undef BT_NAMESPACE
#define BT_NAMESPACE NBT3

#define HASH_ARRAY_2

#include "BinTree.h"
#include "BinTreeMain.h"

#undef HASH_ARRAY_2

#endif
